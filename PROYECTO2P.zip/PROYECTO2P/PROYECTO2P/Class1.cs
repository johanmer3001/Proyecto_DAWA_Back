﻿namespace PROYECTO2P
{
    public class Class1
    {

    }
}
