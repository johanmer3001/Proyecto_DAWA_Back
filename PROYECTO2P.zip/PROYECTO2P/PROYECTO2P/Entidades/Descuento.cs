﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Entidades
{
    public class Descuento
    {
        public int DescuentoId { get; set; }
        public string Descripcion { get; set; }
        public double Porcentaje { get; set; }
    }
}
