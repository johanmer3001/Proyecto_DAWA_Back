﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Entidades
{
    public class DetalleFactura
    {
        public int DetalleFacturaId { get; set; }
        public string DescripcionServicio { get; set; }
        public int Cantidad {  get; set; }
        public double PrecioUnitario { get; set; }
        public double Subtotal { get; set; }
        public int FacturaId { get; set; }
        public virtual Factura Factura { get; set; }
    }
}
