﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Entidades
{
    public class Diagnostico
    {
        public int DiagnosticoId { get; set; }
        public DateOnly FechaHora { get; set; }
        public string Descripcion { get; set; }
        public int HistoriaClinicaId { get; set; }
        public virtual HistoriaClinica HistoriaClinica { get; set; }
    }
}
