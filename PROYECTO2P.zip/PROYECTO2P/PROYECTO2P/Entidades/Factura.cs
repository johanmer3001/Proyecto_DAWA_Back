﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Entidades
{
    public class Factura
    { 
        public int FacturaId { get; set; }
        public DateOnly FechaEmision { get; set; }
        public double Total { get; set; }
        public string MetodoPago { get; set; }
        public string Estado { get;set; }
        public int PacienteId { get; set; }
        public int DescuentoId { get; set; } 
        public virtual Paciente Paciente { get; set; }
        public virtual Descuento Descuento { get; set; }
    }
}
