﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Entidades
{
    public class HistoriaClinica
    {
        public int HistoriaClinicaId { get; set; }
        public DateOnly FechaCreacion { get; set; }
        public string Alergia { get; set; }
        public string MedicacionActual { get; set; }
        public string AntecedenteMedico { get; set; }
        public int PacienteId { get; set; }
        public virtual Paciente Paciente { get; set; }
    }
}
