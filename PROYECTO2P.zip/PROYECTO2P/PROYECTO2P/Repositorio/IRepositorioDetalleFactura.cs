﻿using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public interface IRepositorioDetalleFactura
    {
        Task<DetalleFactura> ObtenerPorIdAsync(int id);
        Task<IEnumerable<DetalleFactura>> ObtenerTodosAsync();
        Task AgregarAsync(DetalleFactura detalleFactura);
        Task ActualizarAsync(DetalleFactura detalleFactura);
        Task EliminarAsync(int id);
    }

}
