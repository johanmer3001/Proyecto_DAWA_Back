﻿using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public interface IRepositorioDiagnostico
    {
        Task<Diagnostico> ObtenerPorIdAsync(int id);
        Task<IEnumerable<Diagnostico>> ObtenerTodosAsync();
        Task AgregarAsync(Diagnostico diagnostico);
        Task ActualizarAsync(Diagnostico diagnostico);
        Task EliminarAsync(int id);
    }

}
