﻿using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public interface IRepositorioFactura
    {
        Task<Factura> ObtenerPorIdAsync(int id);
        Task<IEnumerable<Factura>> ObtenerTodosAsync();
        Task AgregarAsync(Factura factura);
        Task ActualizarAsync(Factura factura);
        Task EliminarAsync(int id);
    }
}
