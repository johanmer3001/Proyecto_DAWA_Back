﻿using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public interface IRepositorioHistoriaClinica
    {
        Task<HistoriaClinica> ObtenerPorIdAsync(int id);
        Task<IEnumerable<HistoriaClinica>> ObtenerTodosAsync();
        Task AgregarAsync(HistoriaClinica historiaClinica);
        Task ActualizarAsync(HistoriaClinica historiaClinica);
        Task EliminarAsync(int id);
    }
}
