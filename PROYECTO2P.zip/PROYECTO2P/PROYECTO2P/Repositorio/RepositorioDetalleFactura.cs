﻿using Microsoft.EntityFrameworkCore;
using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public class RepositorioDetalleFactura : IRepositorioDetalleFactura
    {
        private readonly DbContext _context;

        public RepositorioDetalleFactura(DbContext context)
        {
            _context = context;
        }

        public async Task<DetalleFactura> ObtenerPorIdAsync(int id)
        {
            return await _context.Set<DetalleFactura>().FindAsync(id);
        }

        public async Task<IEnumerable<DetalleFactura>> ObtenerTodosAsync()
        {
            return await _context.Set<DetalleFactura>().ToListAsync();
        }

        public async Task AgregarAsync(DetalleFactura detalleFactura)
        {
            await _context.Set<DetalleFactura>().AddAsync(detalleFactura);
            await _context.SaveChangesAsync();
        }

        public async Task ActualizarAsync(DetalleFactura detalleFactura)
        {
            _context.Set<DetalleFactura>().Update(detalleFactura);
            await _context.SaveChangesAsync();
        }

        public async Task EliminarAsync(int id)
        {
            var detalleFactura = await ObtenerPorIdAsync(id);
            if (detalleFactura != null)
            {
                _context.Set<DetalleFactura>().Remove(detalleFactura);
                await _context.SaveChangesAsync();
            }
        }
    }
}