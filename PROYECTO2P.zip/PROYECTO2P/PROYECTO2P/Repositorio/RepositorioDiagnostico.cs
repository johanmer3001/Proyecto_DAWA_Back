﻿using Microsoft.EntityFrameworkCore;
using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public class RepositorioDiagnostico : IRepositorioDiagnostico
    {
        private readonly DbContext _context;

        public RepositorioDiagnostico(DbContext context)
        {
            _context = context;
        }

        public async Task<Diagnostico> ObtenerPorIdAsync(int id)
        {
            return await _context.Set<Diagnostico>().FindAsync(id);
        }

        public async Task<IEnumerable<Diagnostico>> ObtenerTodosAsync()
        {
            return await _context.Set<Diagnostico>().ToListAsync();
        }

        public async Task AgregarAsync(Diagnostico diagnostico)
        {
            await _context.Set<Diagnostico>().AddAsync(diagnostico);
            await _context.SaveChangesAsync();
        }

        public async Task ActualizarAsync(Diagnostico diagnostico)
        {
            _context.Set<Diagnostico>().Update(diagnostico);
            await _context.SaveChangesAsync();
        }

        public async Task EliminarAsync(int id)
        {
            var diagnostico = await ObtenerPorIdAsync(id);
            if (diagnostico != null)
            {
                _context.Set<Diagnostico>().Remove(diagnostico);
                await _context.SaveChangesAsync();
            }
        }
    }
}
