﻿using Microsoft.EntityFrameworkCore;
using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public class RepositorioFactura : IRepositorioFactura
    {
        private readonly DbContext _context;

        public RepositorioFactura(DbContext context)
        {
            _context = context;
        }

        public async Task<Factura> ObtenerPorIdAsync(int id)
        {
            return await _context.Set<Factura>().FindAsync(id);
        }

        public async Task<IEnumerable<Factura>> ObtenerTodosAsync()
        {
            return await _context.Set<Factura>().ToListAsync();
        }

        public async Task AgregarAsync(Factura factura)
        {
            await _context.Set<Factura>().AddAsync(factura);
            await _context.SaveChangesAsync();
        }

        public async Task ActualizarAsync(Factura factura)
        {
            _context.Set<Factura>().Update(factura);
            await _context.SaveChangesAsync();
        }

        public async Task EliminarAsync(int id)
        {
            var factura = await ObtenerPorIdAsync(id);
            if (factura != null)
            {
                _context.Set<Factura>().Remove(factura);
                await _context.SaveChangesAsync();
            }
        }
    }
}