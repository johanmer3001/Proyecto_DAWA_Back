﻿using Microsoft.EntityFrameworkCore;
using PROYECTO2P.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2P.Repositorio
{
    public class RepositorioHistoriaClinica : IRepositorioHistoriaClinica
    {
        private readonly DbContext _context;

        public RepositorioHistoriaClinica(DbContext context)
        {
            _context = context;
        }

        public async Task<HistoriaClinica> ObtenerPorIdAsync(int id)
        {
            return await _context.Set<HistoriaClinica>().FindAsync(id);
        }

        public async Task<IEnumerable<HistoriaClinica>> ObtenerTodosAsync()
        {
            return await _context.Set<HistoriaClinica>().ToListAsync();
        }

        public async Task AgregarAsync(HistoriaClinica historiaClinica)
        {
            await _context.Set<HistoriaClinica>().AddAsync(historiaClinica);
            await _context.SaveChangesAsync();
        }

        public async Task ActualizarAsync(HistoriaClinica historiaClinica)
        {
            _context.Set<HistoriaClinica>().Update(historiaClinica);
            await _context.SaveChangesAsync();
        }

        public async Task EliminarAsync(int id)
        {
            var historiaClinica = await ObtenerPorIdAsync(id);
            if (historiaClinica != null)
            {
                _context.Set<HistoriaClinica>().Remove(historiaClinica);
                await _context.SaveChangesAsync();
            }
        }
    }
}