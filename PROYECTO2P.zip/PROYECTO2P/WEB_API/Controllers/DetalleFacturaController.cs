﻿using Microsoft.AspNetCore.Mvc;
using PROYECTO2P.Entidades;
using PROYECTO2P.Repositorio;

namespace WEB_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetalleFacturaController : Controller
    {
        private readonly IRepositorioDetalleFactura _repositorioDetalleFactura;

        public DetalleFacturaController(IRepositorioDetalleFactura repositorioDetalleFactura)
        {
            _repositorioDetalleFactura = repositorioDetalleFactura;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<DetalleFactura>>> GetDetallesFacturas()
        {
            var detallesFacturas = await _repositorioDetalleFactura.ObtenerTodosAsync();
            return Ok(detallesFacturas);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<DetalleFactura>> GetDetallesFacturas(int DetalleFacturaId)
        {
            var detallesFacturas = await _repositorioDetalleFactura.ObtenerPorIdAsync(DetalleFacturaId);
            if (detallesFacturas == null)
            {
                return NotFound();
            }
            return Ok(detallesFacturas);
        }

        [HttpPost]
        public async Task<ActionResult<DetalleFactura>> PostDetalleFactura(DetalleFactura detallesFacturas)
        {
            await _repositorioDetalleFactura.AgregarAsync(detallesFacturas);
            return CreatedAtAction(nameof(GetDetallesFacturas), new { id = detallesFacturas.DetalleFacturaId }, detallesFacturas);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutDetalleFactura(int DetalleFacturaId, DetalleFactura detallesFacturas)
        {
            if (DetalleFacturaId != detallesFacturas.DetalleFacturaId)
            {
                return BadRequest();
            }

            await _repositorioDetalleFactura.ActualizarAsync(detallesFacturas);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDetalleFactura(int DetalleFacturaId)
        {
            var detallesFacturas = await _repositorioDetalleFactura.ObtenerPorIdAsync(DetalleFacturaId);
            if (detallesFacturas == null)
            {
                return NotFound();
            }

            await _repositorioDetalleFactura.EliminarAsync(DetalleFacturaId);
            return NoContent();
        }
    }
}
