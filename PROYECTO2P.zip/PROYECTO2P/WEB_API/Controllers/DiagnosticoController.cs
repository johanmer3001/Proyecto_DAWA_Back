﻿using Microsoft.AspNetCore.Mvc;
using PROYECTO2P.Entidades;
using PROYECTO2P.Repositorio;

namespace WEB_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DiagnosticoController : ControllerBase
    {
        private readonly IRepositorioDiagnostico _repositorioDiagnostico;

        public DiagnosticoController(IRepositorioDiagnostico repositorioDiagnostico)
        {
            _repositorioDiagnostico = repositorioDiagnostico;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Diagnostico>>> GetDiagnosticos()
        {
            var diagnosticos = await _repositorioDiagnostico.ObtenerTodosAsync();
            return Ok(diagnosticos);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Diagnostico>> GetDiagnostico(int DiagnosticoId)
        {
            var diagnostico = await _repositorioDiagnostico.ObtenerPorIdAsync(DiagnosticoId);
            if (diagnostico == null)
            {
                return NotFound();
            }
            return Ok(diagnostico);
        }

        [HttpPost]
        public async Task<ActionResult<Diagnostico>> PostDiagnostico(Diagnostico diagnostico)
        {
            await _repositorioDiagnostico.AgregarAsync(diagnostico);
            return CreatedAtAction(nameof(GetDiagnostico), new { id = diagnostico.DiagnosticoId }, diagnostico);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutDiagnostico(int DiagnosticoId, Diagnostico diagnostico)
        {
            if (DiagnosticoId != diagnostico.DiagnosticoId)
            {
                return BadRequest();
            }

            await _repositorioDiagnostico.ActualizarAsync(diagnostico);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDiagnostico(int DiagnosticoId)
        {
            var diagnostico = await _repositorioDiagnostico.ObtenerPorIdAsync(DiagnosticoId);
            if (diagnostico == null)
            {
                return NotFound();
            }

            await _repositorioDiagnostico.EliminarAsync(DiagnosticoId);
            return NoContent();
        }
    }
}
