﻿using Microsoft.AspNetCore.Mvc;
using PROYECTO2P.Entidades;
using PROYECTO2P.Repositorio;

namespace WEB_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FacturaController : Controller
    {
        private readonly IRepositorioFactura _repositorioFactura;

        public FacturaController(IRepositorioFactura repositorioFactura)
        {
            _repositorioFactura = repositorioFactura;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Factura>>> GetFacturas()
        {
            var facturas = await _repositorioFactura.ObtenerTodosAsync();
            return Ok(facturas);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Factura>> GetFacturas(int FacturaId)
        {
            var facturas = await _repositorioFactura.ObtenerPorIdAsync(FacturaId);
            if (facturas == null)
            {
                return NotFound();
            }
            return Ok(facturas);
        }

        [HttpPost]
        public async Task<ActionResult<Factura>> PostFacturas(Factura facturas)
        {
            await _repositorioFactura.AgregarAsync(facturas);
            return CreatedAtAction(nameof(GetFacturas), new { id = facturas.FacturaId }, facturas);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutFacturas(int FacturaId, Factura facturas)
        {
            if (FacturaId != facturas.FacturaId)
            {
                return BadRequest();
            }

            await _repositorioFactura.ActualizarAsync(facturas);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDetalleFactura(int FacturaId)
        {
            var facturas = await _repositorioFactura.ObtenerPorIdAsync(FacturaId);
            if (facturas == null)
            {
                return NotFound();
            }

            await _repositorioFactura.EliminarAsync(FacturaId);
            return NoContent();
        }
    }
}

