﻿using Microsoft.AspNetCore.Mvc;
using PROYECTO2P.Entidades;
using PROYECTO2P.Repositorio;

namespace WEB_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HistoriaClinicaController : Controller
    {
        private readonly IRepositorioHistoriaClinica _repositorioHistoriaClinica;

        public HistoriaClinicaController(IRepositorioHistoriaClinica repositorioHistoriaClinica)
        {
            _repositorioHistoriaClinica = repositorioHistoriaClinica;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<HistoriaClinica>>> GetHistoriasClinicas()
        {
            var historiasClinicas = await _repositorioHistoriaClinica.ObtenerTodosAsync();
            return Ok(historiasClinicas);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HistoriaClinica>> GetHistoriasClinicas(int HistoriaClinicaId)
        {
            var historiasClinicas = await _repositorioHistoriaClinica.ObtenerPorIdAsync(HistoriaClinicaId);
            if (historiasClinicas == null)
            {
                return NotFound();
            }
            return Ok(historiasClinicas);
        }

        [HttpPost]
        public async Task<ActionResult<HistoriaClinica>> PostHistoriasClinicas(HistoriaClinica historiasClinicas)
        {
            await _repositorioHistoriaClinica.AgregarAsync(historiasClinicas);
            return CreatedAtAction(nameof(GetHistoriasClinicas), new { id = historiasClinicas.HistoriaClinicaId }, historiasClinicas);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutHistoriasClinicas(int HistoriaClinicaId, HistoriaClinica historiasClinicas)
        {
            if (HistoriaClinicaId != historiasClinicas.HistoriaClinicaId)
            {
                return BadRequest();
            }

            await _repositorioHistoriaClinica.ActualizarAsync(historiasClinicas);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteHistoriasClinicas(int HistoriaClinicaId)
        {
            var historiasClinicas = await _repositorioHistoriaClinica.ObtenerPorIdAsync(HistoriaClinicaId);
            if (historiasClinicas == null)
            {
                return NotFound();
            }

            await _repositorioHistoriaClinica.EliminarAsync(HistoriaClinicaId);
            return NoContent();
        }
    }
}

