﻿namespace ProyectoGrupo7
{
    public class Class1
    {

    }
}
