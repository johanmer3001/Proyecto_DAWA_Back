﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class ApplicationDBContext : DbContext
    {

        public ApplicationDBContext(DbContextOptions options) : base(options)
        {

        }
        //Para hacer la conexión a la base de datos 
       /* protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=MISHA; Database=Odontologia; Integrated Security=True; TrustServerCertificate=True;");
        }*/

        //Con este codigo se indica que se van a crear las tablas en la BD
        public DbSet<Cita> Citas { get; set; }
        public DbSet<Descuento> Descuentos { get; set; }
        public DbSet<DetallesFactura> DetallesFacturas { get; set; }
        public DbSet<Diagnostico> Diagnosticos { get; set; }
        public DbSet<Doctor> Doctores { get; set; }
        public DbSet<Factura> Facturas { get; set; }
        public DbSet<HistoriaClinica> HistoriaClinicas { get; set; }
        public DbSet<HorarioAtencion> HorarioAtenciones {  get; set; }
        public DbSet<Paciente> Pacientes {  get; set; }
        public DbSet<PerfilPaciente> PerfilPacientes { get; set; }
        public DbSet<Procedimiento> Procedimientos { get; set; }
        public DbSet<Tratamiento> Tratamientos { get; set; }

    }

}

