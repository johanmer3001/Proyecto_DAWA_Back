﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class Cita
    {
        public int CitaId { get; set; }
        public int DoctorId { get; set; }
        public int PacienteId { get; set; }
        public DateTime Fecha {  get; set; }
        public String Estado { get; set; } = null!;

        //relacion entra tablas 
        public virtual Doctor Doctor { get; set; } = null!;
        public virtual Paciente Paciente { get; set; } = null!;
    }
}
