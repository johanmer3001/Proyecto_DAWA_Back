﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public  class Descuento
    {
        public int DescuentoId { get; set; }
        public String Descripcion { get; set; } = null!;
        public decimal Porcentaje { get; set; }



    }
}
