﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class DetallesFactura
    {
        public int DetallesFacturaId { get; set; }
        public int FacturaId { get; set; }  
        public String DescripcionServicio { get; set; } = null!;
        public int Cantidad { get; set; }
        public int PrecioUnitario { get; set; }
        public int Subtotal { get; set; }

        //relacion entre tablas
        public virtual Factura Factura { get; set; } = null!;

    }
}
