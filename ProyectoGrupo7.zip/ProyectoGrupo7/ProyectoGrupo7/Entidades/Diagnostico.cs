﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class Diagnostico
    {
        public int DiagnosticoId { get; set; }
        public int HistoriaClinicaId { get; set; }
        public String Descripcion { get; set; } = null!;
        public DateTime Fecha {  get; set; } 

        //relacion entre tablas
        public virtual HistoriaClinica HistoriaClinica { get; set; } = null!;

    }
}
