﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class Doctor
    {
        public int DoctorId { get; set; }
        public String Nombre { get; set; } = null!;
        public String Especialidad { get; set; } = null!;
        public String Correo { get; set; } = null!;
        public String Telefono { get; set; } = null!;   
        public String Ubicacion { get; set; } = null!;
        public String Disponibilidad { get; set; } = null!;

    }
}
