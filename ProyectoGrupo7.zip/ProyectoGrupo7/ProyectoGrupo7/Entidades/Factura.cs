﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class Factura
    {
        public int FacturaId { get; set; }
        public int PacienteId { get; set; }
        public int DescuentoId { get; set; }
        public int Total { get; set; }
        public String MetodoPago { get; set; } = null!;
        public String Estado { get; set; } = null!;
        public DateTime FechaEmision {  get; set; }

        //relacion entre tablas 
        public virtual Paciente Paciente { get; set; } = null!;
        public virtual Descuento Descuento { get; set; } = null!;

    }
}
