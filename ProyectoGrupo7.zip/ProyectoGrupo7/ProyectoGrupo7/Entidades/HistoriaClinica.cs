﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class HistoriaClinica
    {
        public int HistoriaClinicaId { get; set; }
        public int PacienteId { get; set; }
        public string Alergias { get; set; } = null!;
        public string MedicacionActual { get; set; } = null!;
        public string AntecedentesMedicos { get; set; } = null!;
        public DateTime FechaCreacion {  get; set; }

        //relacion entra tablas 
        public Paciente? Paciente { get; set; } 

    }
}
