﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class HorarioAtencion
    {
        public int HorarioAtencionId { get; set; }
        public int DoctorId { get; set; }
        public String DiasLaborales { get; set; } = null!;      
        public DateTime FechaInicio { get; set; }
        public DateTime FechaSalida { get; set; }

        //relación entra tablas 
        public virtual Doctor Doctor { get; set; } = null!;

    }
}
