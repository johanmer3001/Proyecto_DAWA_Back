﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class Paciente
    {

        public int Id {  get; set; }
        public string nombre { get; set; } = null!;
        public string contraseña { get; set; } = null!;
        public string correo { get; set; } = null!;
        
        public DateTime FechaRegistro { get; set; }

    }
}
