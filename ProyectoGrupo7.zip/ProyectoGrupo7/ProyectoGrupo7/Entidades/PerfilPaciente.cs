﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class PerfilPaciente
    {
        public int PerfilPacienteId { get; set; }
        public int PacienteId { get; set;}
        public String Biografia { get; set; } = null!;

        public byte[] Foto { get; set; }

        //relacion entra tablas 
        public virtual Paciente Paciente { get; set; }= null!;

    }
}
