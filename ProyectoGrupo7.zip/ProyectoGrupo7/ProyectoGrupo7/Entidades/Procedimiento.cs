﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class Procedimiento
    {
        public int ProcedimientoId { get; set; }
        public int HistoriaClinicaId { get; set; }
        public string Descripcion { get; set; } = null!;
        public string Resultado { get; set; } = null!;
        public DateTime Fecha {  get; set; } 

        //relacion entre tablas
        public  HistoriaClinica? HistoriaClinica { get; set; } = null!;

    }
}
