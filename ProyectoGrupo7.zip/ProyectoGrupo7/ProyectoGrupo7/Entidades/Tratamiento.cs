﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Entidades
{
    public class Tratamiento
    {
        public int TratamientoId { get; set; }
        public int HistoriaClinicaId { get; set; }
        public string Descripcion { get; set; } = null!;
        public string DuracionEstimada { get; set; } = null!;
        public DateTime Fecha {  get; set; } 

        //relacion entre tablas
        public  HistoriaClinica? HistoriaClinica { get; set;} 

    }
}
