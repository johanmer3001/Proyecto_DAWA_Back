﻿using ProyectoGrupo7.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Repositorio
{
    public interface IRepositorioProcedimiento
    {
        Task<int> AgregarProcedimiento(Procedimiento procedimiento);
        Task<List<Procedimiento>> ObtenerProcedimiento();
        Task EliminarProcedimiento(int id);
        Task<int> ModificarProcedimiento(Procedimiento proce);
        Task<Procedimiento?> ObtenerPorIdProcedimiento(int id);
    }
}
