﻿using ProyectoGrupo7.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Repositorio
{
    public interface IRepositorioTratamiento
    {
        Task<int> AgregarTratamiento(Tratamiento tratamiento);
        Task<List<Tratamiento>> ObtenerTratamiento();
        Task EliminarTratamiento(int id);
        Task<int> ModificarTratamiento(Tratamiento tratamient);
        Task<Tratamiento?> ObtenerPorId(int id);

    }
}
