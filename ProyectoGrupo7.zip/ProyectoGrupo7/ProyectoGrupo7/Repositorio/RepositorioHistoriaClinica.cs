﻿using Microsoft.EntityFrameworkCore;
using ProyectoGrupo7.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Repositorio
{
    public class RepositorioHistoriaClinica : IRepositorioHistoriaClinica
    {
        private readonly ApplicationDBContext context;

        public RepositorioHistoriaClinica(ApplicationDBContext context)
        {
            this.context = context;
        }

        public async Task<List<HistoriaClinica>> ObtenerHistoriaClinica()
        {
            return await context.HistoriaClinicas.ToListAsync();
        }
    }
}
