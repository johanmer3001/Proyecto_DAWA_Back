﻿using Microsoft.EntityFrameworkCore;
using ProyectoGrupo7.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Repositorio
{
   
    public class RepositorioPaciente : IRepositorioPaciente
    {

        private readonly ApplicationDBContext context;

        public RepositorioPaciente(ApplicationDBContext context)
        {
            this.context = context;
        }
        public async Task<List<Paciente>> ObtenerPaciente()
        {
           
            return await context.Pacientes.ToListAsync();
        }
    }
}
