﻿using Microsoft.EntityFrameworkCore;
using ProyectoGrupo7.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Repositorio
{
    public class RepositorioProcedimiento : IRepositorioProcedimiento
    {
        private readonly ApplicationDBContext context;

        public RepositorioProcedimiento(ApplicationDBContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarProcedimiento(Procedimiento procedimiento)
        {
            context.Procedimientos.Add(procedimiento);
            await context.SaveChangesAsync();
            return procedimiento.ProcedimientoId;
        }

        public async Task EliminarProcedimiento(int id)
        {
            Procedimiento procedimiento = await context.Procedimientos.FindAsync(id);
            context.Procedimientos.Remove(procedimiento);
            await context.SaveChangesAsync();
        }

        public async Task<int> ModificarProcedimiento(Procedimiento proce)
        {
            Procedimiento procedimiento = await context.Procedimientos.FindAsync(proce.ProcedimientoId);
            procedimiento.HistoriaClinicaId = proce.HistoriaClinicaId;
            procedimiento.Descripcion = proce.Descripcion;
            procedimiento.Resultado = proce.Resultado;
            procedimiento.Fecha = proce.Fecha;
            await context.SaveChangesAsync();
            return proce.ProcedimientoId;
        }

        public async Task<Procedimiento?> ObtenerPorIdProcedimiento(int id)
        {
            return await context.Procedimientos.FindAsync(id);
        }

        public  Task<List<Procedimiento>> ObtenerProcedimiento()
        {
            return context.Procedimientos
            .Include(procedimiento => procedimiento.HistoriaClinica)
            .ToListAsync();
        }
    }
}
