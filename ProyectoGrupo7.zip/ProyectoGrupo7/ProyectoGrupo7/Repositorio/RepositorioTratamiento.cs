﻿using Microsoft.EntityFrameworkCore;
using ProyectoGrupo7.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoGrupo7.Repositorio
{
    public class RepositorioTratamiento : IRepositorioTratamiento
    {
        private readonly ApplicationDBContext context;

        public RepositorioTratamiento(ApplicationDBContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarTratamiento(Tratamiento tratamiento)
        {
            context.Tratamientos.Add(tratamiento);
            await context.SaveChangesAsync();
            return tratamiento.TratamientoId;
        }

        public async Task EliminarTratamiento(int id)
        {
            Tratamiento libro = await context.Tratamientos.FindAsync(id);
            context.Tratamientos.Remove(libro);
            await context.SaveChangesAsync();
        }

        public async Task<int> ModificarTratamiento(Tratamiento tratamient)
        {
            Tratamiento tratamiento = await context.Tratamientos.FindAsync(tratamient.TratamientoId);         
            tratamiento.HistoriaClinicaId = tratamient.HistoriaClinicaId;
            tratamiento.Descripcion = tratamient.Descripcion;
            tratamiento.DuracionEstimada = tratamient.DuracionEstimada;
            tratamiento.Fecha = tratamient.Fecha;
            await context.SaveChangesAsync();
            return tratamient.TratamientoId;
        }

        public async Task<Tratamiento?> ObtenerPorId(int id)
        {
            return await context.Tratamientos.FindAsync(id);
        }

        public  Task<List<Tratamiento>> ObtenerTratamiento()
        {
            //return await context.Tratamientos.ToListAsync();
            return context.Tratamientos
        .Include(tratamiento => tratamiento.HistoriaClinica)
        
        .ToListAsync();
        }
    }
}
