﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProyectoGrupo7.Repositorio;

namespace WebApplicationProyectoGrupo7.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HistorialClinicaController : ControllerBase
    {
        private readonly IRepositorioHistoriaClinica _repositorioHistoriaClinica;
        public HistorialClinicaController(IRepositorioHistoriaClinica historiaClinica)
        {
            this._repositorioHistoriaClinica = historiaClinica;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioHistoriaClinica.ObtenerHistoriaClinica();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
