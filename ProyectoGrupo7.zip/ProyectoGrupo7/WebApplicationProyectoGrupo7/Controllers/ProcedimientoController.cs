﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProyectoGrupo7.Entidades;
using ProyectoGrupo7.Repositorio;

namespace WebApplicationProyectoGrupo7.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProcedimientoController : ControllerBase
    {

        private readonly IRepositorioProcedimiento _repositorioProcedimiento;
        public ProcedimientoController(IRepositorioProcedimiento procedimiento)
        {
            this._repositorioProcedimiento = procedimiento;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioProcedimiento.ObtenerProcedimiento();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var libro = await _repositorioProcedimiento.ObtenerPorIdProcedimiento(id);
                return Ok(libro);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(Procedimiento procedimiento)
        {
            try
            {
                procedimiento.Fecha = DateTime.Now;
                var id = await _repositorioProcedimiento.AgregarProcedimiento(procedimiento);
                return Ok(procedimiento);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioProcedimiento.EliminarProcedimiento(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Procedimiento procedimiento)
        {
            try
            {
                await _repositorioProcedimiento.ModificarProcedimiento(procedimiento);
                return Ok(procedimiento.ProcedimientoId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }
    }
}

