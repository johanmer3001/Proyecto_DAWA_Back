﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProyectoGrupo7.Entidades;
using ProyectoGrupo7.Repositorio;

namespace WebApplicationProyectoGrupo7.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TratamientoController : ControllerBase
    {
        private readonly IRepositorioTratamiento _repositorioTratamiento;
        public TratamientoController(IRepositorioTratamiento tratamiento)
        {
            this._repositorioTratamiento = tratamiento;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioTratamiento.ObtenerTratamiento();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var libro = await _repositorioTratamiento.ObtenerPorId(id);
                return Ok(libro);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(Tratamiento tratamiento)
        {
             try
             {
                 tratamiento.Fecha = DateTime.Now;
                var id = await _repositorioTratamiento.AgregarTratamiento(tratamiento);
                 return Ok(tratamiento);
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.Message);
             }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioTratamiento.EliminarTratamiento(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Tratamiento tratamiento)
        {
            try
            {
                await _repositorioTratamiento.ModificarTratamiento(tratamiento);
                return Ok(tratamiento.TratamientoId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }
    }

}

