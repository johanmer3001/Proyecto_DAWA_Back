﻿using HospitalLibreria.Entidades;
using HospitalLibreria.Repositorio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAppHospital.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CitasController : ControllerBase
    {
        private readonly IRepositorioCitas _repositorioCitas;

        public CitasController(IRepositorioCitas repositorioCitas)
        {
            _repositorioCitas = repositorioCitas;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioCitas.ObtenerTodos();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }

        }


        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var citas = await _repositorioCitas.ObtenerPorId(id);
                return Ok(citas);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }

        }

        [HttpGet("por-rango-fecha")]
        public async Task<ActionResult<List<Citas>>> ObtenerPorRangoFecha(DateTime fechaInicio, DateTime fechaFin)
        {
            var citas = await _repositorioCitas.ObtenerPorRangoFecha(fechaInicio, fechaFin);
            return Ok(citas);
        }

        [HttpGet("por-nombre-doctor")]
        public async Task<ActionResult<Citas>> ObtenerPorNombreDoctor(string nombreDoctor)
        {
            var cita = await _repositorioCitas.ObtenerPorNombreDoctor(nombreDoctor);
            if (cita == null)
            {
                return NotFound();
            }
            return Ok(cita);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Citas cita)
        {
            try
            {
                var id = await _repositorioCitas.Crear(cita);
                return Ok(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioCitas.Eliminar(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Citas citas)
        {
            try
            {
                await _repositorioCitas.Modificar(citas);
                return Ok(citas.Id);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }

    }
}
