﻿using HospitalLibreria.Entidades;
using HospitalLibreria.Repositorio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Numerics;

namespace WebAppHospital.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctoresController : ControllerBase
    {
        private readonly IRepositorioDoctores _repositorioDoctores;

        public DoctoresController(IRepositorioDoctores repositorioDoctores)
        {
            _repositorioDoctores = repositorioDoctores;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioDoctores.ObtenerTodos();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }

        }


        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var doctores = await _repositorioDoctores.ObtenerPorId(id);
                return Ok(doctores);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }

        }

        [HttpGet("por-especialidad")]
        public async Task<ActionResult<List<Doctores>>> ObtenerPorEspecialidad([FromQuery] string especialidadDoctor)
        {
            var doctores = await _repositorioDoctores.ObtenerPorEspecialidad(especialidadDoctor);
            if (doctores == null || doctores.Count == 0)
            {
                return NotFound();
            }
            return Ok(doctores);
        }


        [HttpGet("por-disponibilidad")]
        public async Task<ActionResult<List<Doctores>>> ObtenerPorDisponibilidad(bool disponibilidadDoctor)
        {
            var doctores = await _repositorioDoctores.ObtenerPorDisponibilidad(disponibilidadDoctor);
            if (doctores == null || doctores.Count == 0)
            {
                return NotFound();
            }
            return Ok(doctores);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Doctores doctores)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var id = await _repositorioDoctores.Crear(doctores);
                return Ok(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioDoctores.Eliminar(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Doctores doctores)
        {
            try
            {
                await _repositorioDoctores.Modificar(doctores);
                return Ok(doctores.Id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }

        }

    }
}
