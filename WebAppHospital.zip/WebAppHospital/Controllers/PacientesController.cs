﻿using HospitalLibreria.Entidades;
using HospitalLibreria.Repositorio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAppHospital.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PacientesController : ControllerBase
    {
        private readonly IRepositorioPacientes _repositorioPacientes;

        public PacientesController(IRepositorioPacientes repositorioPacientes)
        {
            _repositorioPacientes = repositorioPacientes;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioPacientes.ObtenerTodos();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var pacientes = await _repositorioPacientes.ObtenerPorId(id);
                return Ok(pacientes);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }
        
        [HttpGet("por-rango-fecha")]
        public async Task<ActionResult<List<Pacientes>>> ObtenerPorFechaRegistro(DateTime fechaInicio, DateTime fechaFin)
        {
            var pacientes = await _repositorioPacientes.ObtenerPorFechaRegistro(fechaInicio, fechaFin);
            return Ok(pacientes);
        }   
        
        [HttpGet("por-nombre-paciente")]
        public async Task<ActionResult<Pacientes>> ObtenerPorNombre(string nombrePaciente)
        {
            var pacientes = await _repositorioPacientes.ObtenerPorNombre(nombrePaciente);
            if (pacientes == null)
            {
                return NotFound();
            }
            return Ok(pacientes);
        }
        /*        
        [HttpPost]
        public async Task<IActionResult> Post(Pacientes pacientes)
        {
            try
            {
                var id = await _repositorioPacientes.Crear(pacientes);
                return Ok(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }
        */
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Pacientes pacientes)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var id = await _repositorioPacientes.Crear(pacientes);
                return Ok(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioPacientes.Eliminar(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
                 
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Pacientes pacientes)
        {
            try
            {
                await _repositorioPacientes.Modificar(pacientes);
                return Ok(pacientes.Id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }
    }
}
