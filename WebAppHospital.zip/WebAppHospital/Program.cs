/*
using HospitalLibreria.Entidades;
using HospitalLibreria.Repositorio;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System.Text.Json;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//add Cors
builder.Services.AddCors(options => options.AddPolicy("AllowWebApp",
                                builder => builder.AllowAnyOrigin()
                                .AllowAnyHeader()
                                .AllowAnyMethod()));

// Agrega la conexion de la BD
builder.Services.AddDbContext<ApplicationDbContext>(opciones =>
    opciones.UseSqlServer("name=DefaultConnection"));









builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.Converters.Add(new DateOnlyJsonConverter());
    });









// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Registra un servicio en el contenedor de dependencias con un tiempo de vida "scoped"
// La instancia del servicio ser� creada una vez por solicitud HTTP y
// ser� compartida en todos los lugares donde sea inyectada durante esa solicitud
builder.Services.AddScoped<IRepositorioCitas, RepositorioCitas>();
builder.Services.AddScoped<IRepositorioDoctores, RepositorioDoctores>();
builder.Services.AddScoped<IRepositorioPacientes, RepositorioPacientes>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowWebApp");

app.UseHttpsRedirection();

app.UseRouting();

app.UseAuthorization();

app.MapControllers();

app.Run();







// Define el convertidor personalizado, si es necesario
public class DateOnlyJsonConverter : JsonConverter<DateOnly>
{
    public override DateOnly Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        var dateString = reader.GetString();
        return DateOnly.Parse(dateString);
    }

    public override void Write(Utf8JsonWriter writer, DateOnly value, JsonSerializerOptions options)
    {
        writer.WriteStringValue(value.ToString("yyyy-MM-dd"));
    }
}

*/
























using HospitalLibreria.Entidades;
using HospitalLibreria.Repositorio;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//add Cors
builder.Services.AddCors(options => options.AddPolicy("AllowWebApp",
                                builder => builder.AllowAnyOrigin()
                                .AllowAnyHeader()
                                .AllowAnyMethod()));

// Agrega la conexion de la BD
builder.Services.AddDbContext<ApplicationDbContext>(opciones =>
    opciones.UseSqlServer("name=DefaultConnection"));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Registra un servicio en el contenedor de dependencias con un tiempo de vida "scoped"
// La instancia del servicio ser� creada una vez por solicitud HTTP y
// ser� compartida en todos los lugares donde sea inyectada durante esa solicitud
builder.Services.AddScoped<IRepositorioCitas, RepositorioCitas>();
builder.Services.AddScoped<IRepositorioDoctores, RepositorioDoctores>();
builder.Services.AddScoped<IRepositorioPacientes, RepositorioPacientes>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowWebApp");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
